import React from 'react';
import './App.css';
import Todo from './Todo';

function App() {
  return (
      <Todo/>
      );
}

export default App;
