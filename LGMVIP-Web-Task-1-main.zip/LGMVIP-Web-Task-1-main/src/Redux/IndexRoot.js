import {Reducer} from "./Reducer";
import { combineReducers } from "redux";
const rootReducers =combineReducers({
   Reducer
})
export default rootReducers